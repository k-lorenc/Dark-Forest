﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Hammer : Weapon
    {
        public Hammer(int defence, int attack) : base(WeaponType.Hammer, DamageType.Blunt, defence, attack)
        {
        }
        public override string ToString()
        {
            return "Hammer (defence = " + defence + ", attack = " + attack + ")";
        }
    }
}
