﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class ZombieWarrior : Warrior
    {
        public override void OpponentRecognition()
        {
            Console.WriteLine("Zombie!");
            Console.WriteLine("\n");
            Console.WriteLine("                                (())) 	");
            Console.WriteLine("                               /|x x| 	");
            Console.WriteLine("                              //( - ) 	");
            Console.WriteLine("                      ___.-._/// 		");
            Console.WriteLine("                     /=`_'-'-'/  !!		");
            Console.WriteLine("                     |-{-_-_-}     !		");
            Console.WriteLine("                     (-{-_-_-}    !		");
            Console.WriteLine("                      ({_-_-_}   !		");
            Console.WriteLine("                       }-_-_-}		");
            Console.WriteLine("                       {-_|-_}		");
            Console.WriteLine("                       {-_|_-}		");
            Console.WriteLine("                       {_-|-_}		");
            Console.WriteLine("                       {_-|-_}  ZOT		");
            Console.WriteLine("                   ____%%@ @%%_______	");
            Console.WriteLine("\n");
        }
        public ZombieWarrior(int health, int defence, int attack, Equipment bonusItem) : base(health, defence, attack, bonusItem)
        {
        }
    }
}
