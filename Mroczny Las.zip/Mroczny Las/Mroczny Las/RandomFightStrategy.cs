﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class RandomFightStrategy : FightStrategy
    {
        Random random = new Random();
        public override FightAction NextAction(int currentHealth)
        {
            if (random.Next(2) == 0)
            {
                return FightAction.Attack;
            }
            else
            {
                return FightAction.Defence;
            }
        }
    }
}
