﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Shield : Equipment
    {
        public Shield(int defence, int attack) : base(WeaponType.Shield, DamageType.Blunt, defence, attack)
        {
        }
        public override string ToString()
        {
            return "Shield (defence = " + defence + ", attack = " + attack + ")";
        }
    }

    
}
