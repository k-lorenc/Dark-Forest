﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Axe : Weapon
    {
        public Axe(int defence, int attack) : base(WeaponType.Hammer, DamageType.Blunt, defence, attack)
        {
        }
        public override string ToString()
        {
            return "Axe (defence = " + defence + ", attack = " + attack + ")";
        }
    }
}
