﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class SkeletonArcher : Archer
    {
        public override void OpponentRecognition()
        {
            Console.WriteLine("This is a skeleton!");
            Console.WriteLine("\n");
            Console.WriteLine("              .7	");
            Console.WriteLine("            .'/	");
            Console.WriteLine("           / /	");
            Console.WriteLine("          / /	");
            Console.WriteLine("         / /		");
            Console.WriteLine("        / /	");
            Console.WriteLine("       / /");
            Console.WriteLine("      / /");
            Console.WriteLine("     / /    ");
            Console.WriteLine("    / /        ");
            Console.WriteLine("  __|/");
            Console.WriteLine(",-|__| ");
            Console.WriteLine("|f-'Y|| ");
            Console.WriteLine("|()7L/");
            Console.WriteLine(" cgD                            __ _");
            Console.WriteLine(" ||(                          .'  Y '>,");
            Console.WriteLine("  | |                        / _   _   ) ");
            Console.WriteLine("   ((                       )(_) (_)(|}");
            Console.WriteLine("    ((                      {  4A   } /");
            Console.WriteLine("     ((                      |uLuJJ/|l");
            Console.WriteLine("      ((                     |3    p)/");
            Console.WriteLine("       ((___ __________      /nnm_n//");
            Console.WriteLine("       c7___-__,__-)|,__)('.  |_ > -< _ / D ");
            Console.WriteLine("                  //V     |_' -._.__G G_c__.- __ < '/ ( | ");
            Console.WriteLine("                         <' -._ > __ -, G_.___)|   |7| ");
            Console.WriteLine("                        (' -.__.| |'<.__.-')        | | ");
            Console.WriteLine("                        |' -.__'|  |' -.__.- '.|     | |");
            Console.WriteLine("                        (' -.__''. |  '-.__.-'.|      |_|");
            Console.WriteLine("                        |'-.__''|! |' -.__.- '.)       | | ");
            Console.WriteLine("                        ' -.__''|_ | '-.__.-''./        | l");
            Console.WriteLine("                          '.__'''>G>-.__.-' >           .--, _");
            Console.WriteLine("\n");
        }
        public SkeletonArcher(int health, int defence, int attack, Equipment bonusItem) : base(health, defence, attack, bonusItem)
        {
        }
    }
}
