﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    abstract class OpponentFactory
    {
        public abstract Archer CreateArcher(int health, int defence, int attack, Equipment bonusItem);
        public abstract Warrior CreateWarrior(int health, int defence, int attack, Equipment bonusItem);
        public abstract Warrior CreateBoss(int health, int defence, int attack, Equipment bonusItem);
    }
}
