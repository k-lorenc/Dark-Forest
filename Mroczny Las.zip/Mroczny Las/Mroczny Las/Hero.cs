﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Hero
    {
        public int DetermineCurrentAttack()
        {
            if (weapon == null)
            {
                return 5;
            }
            else
            {
                return weapon.attack;
            }

        }
        public int DetermineCurrentDefence()
        {
            int result = 5;

            if (weapon != null)
            {
                result += weapon.defence;
            }

            if (shield != null)
            {
                result += shield.defence;
            }

            return result;
        }

        public int health = 100;
        public Weapon weapon;
        public Shield shield;
        FightStrategy fightStrategy;


        public void SetFightStrategy(FightStrategy fightStrategy)
        {
            this.fightStrategy = fightStrategy;
        }
        public void SetWeapon(Weapon weapon)
        {
            this.weapon = weapon;
        }
        public void SetShield(Shield shield)
        {
            this.shield = shield;
        }

        public FightStrategy GetFightStrategy()
        {
            return fightStrategy;
        }
        public Shield GetShield()
        {
            return shield;
        }
        public Weapon GetWeapon()
        {
            return weapon;
        }
    }
}
