﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    public class Program
    {
        public static void Main(string[] args)
        {
            OpponentFactory undeadOpponentFactory = new UndeadOpponentFactory();
            OpponentFactory mysticalOpponentFactory = new MysticalOpponentFactory();

            Hero hero = new Hero();

            hero.SetFightStrategy(new RandomFightStrategy());

            Location campLocation = new Location("Camp");
            Location skeletonLocation = new Location("Skeleton Cave");
            Location dwarfLocation = new Location("Dwarf Cave");
            Location zombieLocation = new Location("Zombie Cave");
            Location centaurLocation = new Location("Centaur Cave");
            Location possessedEnt = new Location("Ent's Coppice");
            Location forestGlade1 = new Location("Forest Glade");
            Location forestGlade2 = new Location("Forest Glade");
            Location forestGlade3 = new Location("Forest Glade");
            Location forestGlade4 = new Location("Forest Glade");
            Location forestGlade5 = new Location("Forest Glade");
            Location mysteriousPond = new Location("Mysterious Pond");

            campLocation.SetNeighbour(Location.NORTH, skeletonLocation);
            campLocation.SetNeighbour(Location.WEST, forestGlade1);
            campLocation.SetNeighbour(Location.EAST, forestGlade2);
            
            forestGlade1.SetNeighbour(Location.EAST, campLocation);
            forestGlade1.SetNeighbour(Location.WEST, zombieLocation);

            zombieLocation.SetNeighbour(Location.EAST, forestGlade1);
            zombieLocation.SetNeighbour(Location.WEST, forestGlade3);
            zombieLocation.SetNeighbour(Location.SOUTH, dwarfLocation);

            dwarfLocation.SetNeighbour(Location.NORTH, zombieLocation);

            forestGlade3.SetNeighbour(Location.EAST, zombieLocation);
            forestGlade3.SetNeighbour(Location.SOUTH, mysteriousPond);

            mysteriousPond.SetNeighbour(Location.NORTH, forestGlade3);

            forestGlade2.SetNeighbour(Location.WEST, campLocation);
            forestGlade2.SetNeighbour(Location.EAST, forestGlade4);
            forestGlade2.SetNeighbour(Location.NORTH, centaurLocation);

            centaurLocation.SetNeighbour(Location.SOUTH, forestGlade2);

            forestGlade4.SetNeighbour(Location.WEST, forestGlade2);

            skeletonLocation.SetNeighbour(Location.SOUTH, campLocation);
            skeletonLocation.SetNeighbour(Location.NORTH, forestGlade5);

            forestGlade5.SetNeighbour(Location.SOUTH, skeletonLocation);
            forestGlade5.SetNeighbour(Location.NORTH, possessedEnt);

            possessedEnt.SetNeighbour(Location.SOUTH, forestGlade5);


            centaurLocation.SetOpponent(mysticalOpponentFactory.CreateArcher(40, 10, 10, new Bow(1, 30)));
            skeletonLocation.SetOpponent(undeadOpponentFactory.CreateArcher(80, 15, 10, new Bow(1, 40)));
            dwarfLocation.SetOpponent(mysticalOpponentFactory.CreateWarrior(100, 15, 15, new Shield(80, 1)));
            zombieLocation.SetOpponent(undeadOpponentFactory.CreateWarrior(60, 10, 20, new Hammer(20, 50)));
            possessedEnt.SetOpponent(mysticalOpponentFactory.CreateBoss(200, 40, 30, new Sword(100, 100)));

            forestGlade4.AddEquipment(new Sword(5, 10));
            forestGlade5.AddEquipment(new Axe(95, 90));

            Location currentLocation = campLocation;
            bool running = true;

            Console.WriteLine("_______________________________________________________________________________________________________________");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("    _/_/_/      _/_/    _/_/_/    _/    _/      _/_/_/_/    _/_/    _/_/_/    _/_/_/_/    _/_/_/  _/_/_/_/_/   ");
            Console.WriteLine("   _/    _/  _/    _/  _/    _/  _/  _/        _/        _/    _/  _/    _/  _/        _/            _/        ");
            Console.WriteLine("  _/    _/  _/_/_/_/  _/_/_/    _/_/          _/_/_/    _/    _/  _/_/_/    _/_/_/      _/_/        _/         ");
            Console.WriteLine(" _/    _/  _/    _/  _/    _/  _/  _/        _/        _/    _/  _/    _/  _/              _/      _/          ");
            Console.WriteLine("_/_/_/    _/    _/  _/    _/  _/    _/      _/          _/_/    _/    _/  _/_/_/_/  _/_/_/        _/  	      ");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("_______________________________________________________________________________________________________________");
            Console.ReadLine();
            Console.WriteLine("Hello adventurer! You woke up in a mysterious and completely unknown place. ");
            Console.WriteLine("Your priority is to get out of here. This task will not be easy.");
            Console.WriteLine("On your way you will encounter terrifying creatures and many strange places. Beware and good luck.");
            Console.ReadLine();
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("Quick instruction: ");
            Console.WriteLine("     1. You can check Your statistics during any point of the game by typing 'stats' ");
            Console.WriteLine("     2. There are four different directions implemented into the game: north, south, east and west. ");
            Console.WriteLine("        You can travel in a posibble direction by typing e.g. 'go S' or 'go N'. ");
            Console.WriteLine("     3. You will find a lot of equipment which You can use during the game. ");
            Console.WriteLine("        To pick it up type 'pick <insert the correct number>'. ");
            Console.WriteLine("     4. In a situation where you will encounter an enemy, you will be asked if You want to fight it. ");
            Console.WriteLine("        Simply answer 'Yes' or 'No'. ");
            Console.WriteLine("     5. I would recommend You to draw a map so You wouldn't get lost.");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.WriteLine("\n");
            Console.ReadLine();


            while (running == true)
            {
                Console.WriteLine("You are in a " + currentLocation.name);
                if (currentLocation.opponent != null)
                {
                    Console.WriteLine("You're facing an enemy! ");
                    currentLocation.opponent.OpponentRecognition();
                    Console.WriteLine("Are You willing to fight?");
                    string userDecision = Console.ReadLine();

                    switch (userDecision)
                    {
                        case "Yes":
                            Fight(hero, currentLocation.opponent);
                            if (hero.health <= 0)
                            {
                                Console.WriteLine("GAME OVER!!!");
                                Console.WriteLine("\n");
                                Console.WriteLine("\n");
                                return;
                            }
                            else
                            {
                                Console.WriteLine("You have killed the Enemy!!!");
                                Console.WriteLine("The Enemy dropped a weapon: " + currentLocation.opponent.bonusItem);
                                Console.Write('\n');

                                currentLocation.equipment.Add(currentLocation.opponent.bonusItem);
                                currentLocation.opponent = null;
                                
                                if (currentLocation == possessedEnt && possessedEnt.opponent == null)
                                {
                                    Console.WriteLine("CONGRATULATIONS!!!");
                                    Console.WriteLine("You have managed to escape from this awful place.");
                                    Console.WriteLine("\n");
                                    Console.WriteLine("You have won the game! <3");
                                    Console.ReadLine();

                                    return;
                                }
                            }
                            break;
                        case "No":
                            break;
                    }
                }

                if (currentLocation == campLocation)
                {
                    Console.WriteLine("You rested and recovered all health.");
                    Console.WriteLine("\n");
                    hero.health = 100;
                }

                
                if (currentLocation == mysteriousPond)
                {
                    Console.WriteLine("You have encountered the most beautiful place that You have ever seen, but something doesn't feel right.");
                    Console.WriteLine("Do You want to explore it?");
                    Console.WriteLine("\n");
                    string UserChoice2 = Console.ReadLine();
                    switch (UserChoice2)
                    {
                        case "Yes":
                            Console.WriteLine("The beauty of this place is too much for You to handle. You have lost Your mind and starved Yourself to death.");
                            Console.WriteLine("\n");
                            Console.WriteLine("GAME OVER!");
                            Console.ReadLine();
                            return;
                            break;
                        case "No":
                            Console.WriteLine("You have almost went crazy... Pull Yourself back together!");
                            Console.WriteLine("\n");
                            break;
                                    }
                }

                if (currentLocation.equipment.Count > 0)
                {
                    Console.WriteLine("Available equipment: ");

                    for (int i = 0; i < currentLocation.equipment.Count; i++)
                    {
                        Console.WriteLine((i + 1) + ". " + currentLocation.equipment[i]);
                    }
                }

                Console.WriteLine("You can go to: ");
                
                for(int i=0; i < 4; i++)
                {
                    if(currentLocation.neighbours[i]!= null)
                    {
                        string directionName = "";
                        switch (i)
                        {
                            case Location.EAST:
                                directionName = "east";
                                break;
                            case Location.NORTH:
                                directionName = "north";
                                break;
                            case Location.SOUTH:
                                directionName = "south";
                                break;
                            case Location.WEST:
                                directionName = "west";
                                break;
                        }
                        Console.WriteLine(directionName + ": " + currentLocation.neighbours[i].name);
                    }
                }
                Console.WriteLine("\n");


                string userChoice = Console.ReadLine();

                string[] parts = userChoice.Split(" ");
                
                if(parts.Length == 0)
                {
                    Console.WriteLine("WRONG COMMAND!");
                    Console.WriteLine("\n");
                }

                else if (parts[0] == "go")
                {
                    if (parts.Length == 2)
                    {
                        Location neighbour = null;
                        switch (parts[1])
                        {
                            case "E":
                                neighbour = currentLocation.neighbours[Location.EAST];
                                break;
                            case "W":
                                neighbour = currentLocation.neighbours[Location.WEST];
                                break;
                            case "N":
                                neighbour = currentLocation.neighbours[Location.NORTH];
                                break;
                            case "S":
                                neighbour = currentLocation.neighbours[Location.SOUTH];
                                break;
                        }
                        if (neighbour != null)
                        {
                            currentLocation = neighbour;
                        }
                        else
                        {
                            Console.WriteLine("Wrong direction!");
                            Console.WriteLine("\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("WRONG COMMAND FORMAT!");
                        Console.WriteLine("\n");
                    }
                }
                else if (parts[0] == "pick")
                {
                    if (parts.Length == 2)
                    {
                        int index = Int32.Parse(parts[1]) - 1;

                        if (index < currentLocation.equipment.Count)
                        {
                            Equipment e = currentLocation.equipment[index];
                            if (e.weaponType == WeaponType.Shield)
                            {
                                if (hero.shield == null)
                                {
                                    hero.shield = (Shield)e;
                                    currentLocation.equipment.RemoveAt(index);
                                }
                                else
                                {
                                    Shield old = hero.shield;
                                    hero.shield = (Shield)e;
                                    currentLocation.equipment[index] = old;
                                }

                            }
                            else
                            {
                                if (hero.weapon == null)
                                {
                                    hero.weapon = (Weapon)e;
                                    currentLocation.equipment.RemoveAt(index);
                                }
                                else
                                {
                                    Weapon old = hero.weapon;
                                    hero.weapon = (Weapon)e;
                                    currentLocation.equipment[index] = old;
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("WRONG NUMBER!");
                        Console.WriteLine("\n");
                    }
                }
                else if(parts[0] == "stats")
                {
                    if(parts.Length == 1)
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("Stats: ");
                        Console.WriteLine("  - health: " + hero.health);
                        if (hero.weapon == null && hero.shield == null)
                        {
                            Console.WriteLine("  - defence: 5");
                            Console.WriteLine("  - attack: 5");
                            Console.WriteLine("  - current equipment: none");
                            Console.WriteLine("\n");
                        }
                        else if (hero.weapon != null && hero.shield == null)
                        {
                            Console.WriteLine("  - defence: " + (hero.weapon.defence + 5));
                            Console.WriteLine("  - attack: " + (hero.weapon.attack + 5));
                            Console.WriteLine("  - current equipment: " + hero.weapon);
                            Console.WriteLine("\n");
                        }
                        else if (hero.weapon == null && hero.shield != null)
                        {
                            Console.WriteLine("  - defence: " + (hero.shield.defence + 5));
                            Console.WriteLine("  - attack: " + (hero.shield.attack + 5));
                            Console.WriteLine("  - current equipment: " + hero.shield);
                            Console.WriteLine("\n");
                        }
                        else
                        {
                            Console.WriteLine("  - defence: " + (hero.weapon.defence + hero.shield.defence + 5));
                            Console.WriteLine("  - attack: " + (hero.weapon.attack + hero.shield.attack + 5));
                            Console.WriteLine("  - current equipment: " + hero.weapon + " and " + hero.shield);
                            Console.WriteLine("\n");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("\n");
                    Console.WriteLine("WRONG COMMAND!");
                    Console.WriteLine("\n");
                }
            }
        }
        static void Fight(Hero hero, Opponent opponent)
        {
            FightStrategy heroStrategy = hero.GetFightStrategy();
            FightStrategy opponentStrategy = opponent.GetFightStrategy();

            int heroAttack = hero.DetermineCurrentAttack();
            int heroDefence = hero.DetermineCurrentDefence();

            while (opponent.health > 0 && hero.health > 0) 
            {
                FightAction heroAction = heroStrategy.NextAction(hero.health);
                FightAction opponentAction = opponentStrategy.NextAction(opponent.health);

                Console.WriteLine("Current Round:");

                if (opponentAction == FightAction.Attack && heroAction == FightAction.Attack)
                {
                    Console.WriteLine("You both attacked, nothing happens.");
                }
                else if (opponentAction == FightAction.Defence && heroAction == FightAction.Defence)
                {
                    Console.WriteLine("You are both defending, nothing happens.");
                }
                else if (opponentAction == FightAction.Defence && heroAction == FightAction.Attack)
                {
                    if (heroAttack > opponent.defence)
                    {
                        opponent.health -= heroAttack;
                    }
                    else
                    {
                        opponent.health -= (heroAttack / 2);
                    }
                    Console.WriteLine("The enemy takes a hit!!!");
                }
                else if (opponentAction == FightAction.Attack && heroAction == FightAction.Defence)
                {
                    if (opponent.attack > heroDefence)
                    {
                        hero.health -= opponent.attack;
                    }
                    else
                    {
                        hero.health -= (opponent.attack / 2);
                    }
                    Console.WriteLine("Unfortunately You have taken a hit...");
                }
                Console.WriteLine("Your current health: " + hero.health);
                Console.WriteLine("Enemys current health: " + opponent.health);
                Console.WriteLine('\n');

                Console.ReadLine();
            }           
        }
    }
}