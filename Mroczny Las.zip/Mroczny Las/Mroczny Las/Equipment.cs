﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    public class Equipment
    {
        public WeaponType weaponType;
        public DamageType damageType;
        public int defence { get; set; }
        public int attack { get; set; }

        protected Equipment(WeaponType weaponType, DamageType damageType, int defence, int attack)
        {
            this.weaponType = weaponType;
            this.damageType = damageType;
            this.attack = attack;
            this.defence = defence;
        }
    }
}
