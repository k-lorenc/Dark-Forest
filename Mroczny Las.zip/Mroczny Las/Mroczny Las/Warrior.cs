﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Warrior : Opponent
    {
        public override void OpponentRecognition()
        {
            Console.WriteLine("Warrior: ");
        }
        public Warrior(int health, int defence, int attack, Equipment bonusItem) : base(health, defence, attack, bonusItem)
        {
        }
    }
}
