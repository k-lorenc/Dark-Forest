﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Bow : Weapon
    {
        public Bow(int defence, int attack) : base(WeaponType.Bow, DamageType.Pierce, defence, attack)
        {
        }
        public override string ToString()
        {
            return "Bow (defence = " + defence + ", attack = " + attack + ")"; 
        }
    }
}
