﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Sword : Weapon
    {
        public Sword(int defence, int attack) : base(WeaponType.Sword, DamageType.Cut, defence, attack)
        {
        }
        public override string ToString()
        {
            return "Sword (defence = " + defence + ", attack = " + attack + ")";
        }
    }
}
