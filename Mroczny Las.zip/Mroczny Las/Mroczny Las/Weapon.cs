﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Weapon : Equipment
    {
        public Weapon(WeaponType weaponType, DamageType damageType, int defence, int attack) : base(weaponType, damageType, defence, attack)
        {
        }
    }
}
