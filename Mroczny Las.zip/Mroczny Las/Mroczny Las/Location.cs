﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Location
    {
        public string name;
        public Location[] neighbours = new Location[4];
        public Opponent opponent;
        public List<Equipment> equipment = new List<Equipment>();

        public const int NORTH = 0;
        public const int SOUTH = 1;
        public const int EAST = 2;
        public const int WEST= 3;

        public Location(string name)
        {
            this.name = name;
        }

        public void SetOpponent(Opponent opponent)
        {
            this.opponent = opponent;
        }

        public void SetNeighbour(int direction, Location neighbour)
        {
            neighbours[direction] = neighbour;
        }

        public void AddEquipment(Equipment e)
        {
            equipment.Add(e);
        }
    }
}
