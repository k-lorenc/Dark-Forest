﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    class UndeadOpponentFactory : OpponentFactory
    {
        public override Archer CreateArcher(int health, int defence, int attack, Equipment bonusItem)
        {
            return new SkeletonArcher(health, defence, attack, bonusItem);
        }
        public override Warrior CreateWarrior(int health, int defence, int attack, Equipment bonusItem)
        {
            return new ZombieWarrior(health, defence, attack, bonusItem);
        }
        public override Warrior CreateBoss(int health, int defence, int attack, Equipment bonusItem)
        {
            return new ZombieWarrior(health, defence, attack, bonusItem);
        }
    }
}
