﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class CentaurArcher : Archer
    {
        public override void OpponentRecognition()
        {
            Console.WriteLine("Centaur!");
            Console.WriteLine("\n");
            Console.WriteLine("                  __			");
            Console.WriteLine("                 / _| #		");
            Console.WriteLine("                 (c /  #		");
            Console.WriteLine("                 / |___ #		");
            Console.WriteLine("                 |`----`#==>  	");
            Console.WriteLine("                 |  |  #		");
            Console.WriteLine("    ,%.-'''-- - '`--'|#_		");
            Console.WriteLine("   %%/             |__`)		");
            Console.WriteLine("  .%'|     |   |   /  //		");
            Console.WriteLine("  ,%' >   .'----| |  [/		");
            Console.WriteLine("     < <<`       ||			");
            Console.WriteLine("      `|||       ||			");
            Console.WriteLine("        )||      )|			");
            Console.WriteLine("^^^^^^^^***^^^^^^**^^^^^^^^^^	");
            Console.WriteLine("\n");
        }
        public CentaurArcher(int health, int defence, int attack, Equipment bonusItem) : base(health, defence, attack, bonusItem)
        {
        }
    }
}
