﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class DwarfWarrior : Warrior
    {
        public override void OpponentRecognition()
        {
            Console.WriteLine("Dwarf!");
            Console.WriteLine("\n");

            Console.WriteLine("                           __.--|~|--.__                            ,,;/; ");
            Console.WriteLine("                         /~     | |    ;~|                        ,;;;/;;' ");
            Console.WriteLine("                        /|      | |    ;~||                     ,;;;;/;;;' ");
            Console.WriteLine("                       |/|      (_)   ;;;||                    ,;;;;/;;;;' ");
            Console.WriteLine("                       |/ |          ;;;/  )                 ,;;;;/;;;;;' ");
            Console.WriteLine("                   ___ | ______     ;_____ |___....__      ,;;;;/;;;;;' ");
            Console.WriteLine("             ___.-~ ||(| |  |.| |__| /./ /:|)~   ~   |   ,;;;;/;;;;;' ");
            Console.WriteLine("         /~~~    ~|    |  ~-.     |   .-~: |//  _.-~~--,;;;;/;;;;;' ");
            Console.WriteLine("        (.-~___     |.'|    | |-.__.-||::::| //~     ,;;;;/;;;;;' ");
            Console.WriteLine("        /      ~~--._ ||   /          `|:: |/      ,;;;;/;;;;;' ");
            Console.WriteLine("     .-|             ~~|   |  |V''''V| |:  |     ,;;;;/;;;;;' | ");
            Console.WriteLine("    /                   |  |  ~`^~~^'~ |  /    ,;;;;/;;;;;'    ; ");
            Console.WriteLine("   (        |             ||`|._____.|'|/    ,;;;;/;;;;;'      '| ");
            Console.WriteLine("  / |        |                             ,;;;;/;;;;;'     /    | ");
            Console.WriteLine(" |            |                          ,;;;;/;;;;;'      |     | ");
            Console.WriteLine("|`-._          |                       ,;;;;/;;;;;'              | ");
            Console.WriteLine("|             /                      ,;;;;/;;;;;'  | |__________ ");
            Console.WriteLine("(             )                 |  ,;;;;/;;;;;'      |        _.--~ ");
            Console.WriteLine(" |          |/ |              ,  ;;;;;/;;;;;'       /( .-~_..--~~~~~~~~~~ ");
            Console.WriteLine(" |__         '  `       ,     ,;;;;;/;;;;;'    .   /  |   / /~ ");
            Console.WriteLine(" /          |'  |`._______ ,;;;;;;/;;;;;;'    /   :    |/'/'       /|_/| ``| ");
            Console.WriteLine("| _.-~~~~-._ |   | __   .,;;;;;;/;;;;;;' ~~~~'   .'    | |       /~ (/|/  || ");
            Console.WriteLine("/~ _.-~~~-._|    /~/   ;;;;;;;/;;;;;;;'          |    | |       / ~/_-'|- /| ");
            Console.WriteLine("(/~         || /' |   ;;;;;;/;;;;;;;;            ;   | |       (.-~;  /- / | ");
            Console.WriteLine("|            /___ `-,;;;;;/;;;;;;;;'            |   | |      ,/)  /  /- /  | ");
            Console.WriteLine(" |            |  `-.`---/;;;;;;;;;' |          _'   | |    /'('  /  /|- _/ // ");
            Console.WriteLine("   |           /~~/ `-. |;;;;;''    ______.--~~ ~|  | |  ,~)')  /   | |~-==// ");
            Console.WriteLine("     |      /~(   `-|  `-.`-;   /|    ))   __-####| | |   (,   /|    |  | ");
            Console.WriteLine("       |  /~.  `-.   `-.( `-.`~~ /##############'~~)| |   '   / |    | ~| ");
            Console.WriteLine("        |(   |    `-._ /~)_/|  /############'       | |      /  |     |_| `| ");
            Console.WriteLine("        ,~`|  `-._  / )#####|/############'   /     | |  _--~ _/ | .-~~____--' ");
            Console.WriteLine("       ,'|  `-._  ~)~~ `################'           | | ((~>/~   | (((' -_ ");
            Console.WriteLine("     ,'   `-.___)~~      `#############             | |           ~-_ ~|_ ");
            Console.WriteLine(" _.,'        ,'           `###########              | |            _-~-__ ( ");
            Console.WriteLine("|  `-.     ,'              `#########       |       | | ((.-~~~-~_--~ ");
            Console.WriteLine("`|    `-.;'                  `#####'                | |           ' ((.-~~ ");
            Console.WriteLine("  `-._   )               |     |   |        .       |  |                 ' ");
            Console.WriteLine("      `~~  _/                  |    (               | `--------------------- ");
            Console.WriteLine("        |/~                `.  |     (        .     |  O __.--------------- ");
            Console.WriteLine("         |                   | ;      (             |   _.-~ " );
            Console.WriteLine("         |                    |        |            |  /  | ");
            Console.WriteLine("          |                   |         |           | /'  |' ");
            Console.WriteLine("\n");
        }

        public DwarfWarrior(int health, int defence, int attack, Equipment bonusItem) : base(health, defence, attack, bonusItem)
        {
        }
    }
}
