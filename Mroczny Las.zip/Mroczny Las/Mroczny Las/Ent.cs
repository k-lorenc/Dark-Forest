﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    internal class Ent : Warrior
    {
        public override void OpponentRecognition()
        {
            Console.WriteLine("I think this tree is looking at me!");
            Console.WriteLine("\n");
            Console.WriteLine("                              _ .-'                                           ");
            Console.WriteLine("                              _`/`                                            ");
            Console.WriteLine("                          `._/` ;_.  /,                                       ");
            Console.WriteLine("                             `. /  _ /`                                       ");
            Console.WriteLine("                               ;_ _,;                                         ");
            Console.WriteLine("                             _/ , , /_,                                       ");
            Console.WriteLine("                             `'/ _ | '                                        ");
            Console.WriteLine("                             _=}  ` ;/                                        ");
            Console.WriteLine("                            .'    `. `-._                                     ");
            Console.WriteLine("                          ,_/ ,| '    {  `.                                   ");
            Console.WriteLine("                          ] ',/  ; , ;| , |_                                  ");
            Console.WriteLine("                          `._L`|  `  | `.` :`                                 ");
            Console.WriteLine("                           `'` | / ; [J./ _                                   ");
            Console.WriteLine("                              /   .   `. ` `'                                 ");
            Console.WriteLine("                             { ;' ||`._ |                                     ");
            Console.WriteLine("                             | `  ; J  ` |                                    ");
            Console.WriteLine("                            /_|_/__}{_|_/_)                                   ");

        }
        public Ent(int health, int defence, int attack, Equipment bonusItem) : base(health, defence, attack, bonusItem)
        {
        }
    }
}
