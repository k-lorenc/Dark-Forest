﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    abstract internal class Opponent
    {
        public int health { get; set; }
        public int defence { get; set; }
        public int attack { get; set; }
        public Equipment bonusItem;
        FightStrategy fightStrategy;

        public abstract void OpponentRecognition();

        public void SetFightStrategy(FightStrategy fightStrategy)
        {
            this.fightStrategy = fightStrategy;
        }
        public FightStrategy GetFightStrategy()
        {
            return fightStrategy;
        }

        protected Opponent(int health, int defence, int attack, Equipment bonusItem)
        {
            this.health = health;
            this.defence = defence;
            this.attack = attack;
            this.bonusItem = bonusItem;
            this.fightStrategy = new RandomFightStrategy();
        }
    }
}
