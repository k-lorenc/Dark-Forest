﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mroczny_Las
{
    class MysticalOpponentFactory : OpponentFactory
    {
        public override Archer CreateArcher(int health, int defence, int attack, Equipment bonusItem)
        {
            return new CentaurArcher(health, defence, attack, bonusItem);
        }
        public override Warrior CreateWarrior(int health, int defence, int attack, Equipment bonusItem)
        {
            return new DwarfWarrior(health, defence, attack, bonusItem);
        }
        public override Warrior CreateBoss(int health, int defence, int attack, Equipment bonusItem)
        {
            return new Ent(health, defence, attack, bonusItem);
        }
    }
}
